
Here you find the package "cyclic" which is explained in the tutorial paper ("Analyzing cyclic patterns in psychological data_a tutorial") that explains how cyclic trends can be fitted to longitudinal (ESM/EMA) data.
In the file "Appendix" all R-code, which is used in this tutorial, is demonstrated and annotated. 
The R-functions that were developped for this tutorial make it easy to use cyclic models. 
The data sets used for the example (Smokedat and pdat) can also be found here.
